import os
from flask import Flask,flash, render_template_string, render_template, jsonify, request, send_from_directory, redirect, url_for
import random
import pickle
import pickletools
import haxxor
import base64

app = Flask(__name__)

allowedOperation = "haxxor"

@app.route('/fetch', methods=['POST'])
def fetchname():
    name = request.form.get('name')
    if(name=='haxxor'):
        data = {'haxxor':'haxxor'}
        p = pickle.dumps(data)
        return redirect(url_for('flag')+"?name="+base64.b64encode(p).decode('utf-8'))
    else:
        return render_template('failure.html')

@app.route('/flag')
def flag():
    name = base64.b64decode(request.args.get('name'))
    for p in pickletools.genops(name):
        if(p[1]==None or isinstance(p[1],int)):
            continue
        for op in str(p[1]).lower():
            if(op not in allowedOperation):
                return jsonify({'Error':'NO HACKING!!!'})
    key = pickle.loads(name)
    return render_template('success.html',result=haxxor.haxxor(key['haxxor']))

@app.route('/')
def index():
   return render_template('index.html')

@app.errorhandler(403)
def custom403(error):
    return jsonify({'Error': error.description})

@app.route('/favicon.ico')
def favicon():
    return send_from_directory(os.path.join(app.root_path, 'static'), 'favicon.ico', mimetype='image/vnd.microsoft.icon')

if __name__ == '__main__':
   app.run()
