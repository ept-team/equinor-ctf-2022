def xor(v1,v2):
    return "".join([chr(ord(a) ^ ord(b)) for a,b in zip(str(v1), str(v2))])

def haxxor(haxxor):
    with open("/fake_flag.txt","r") as f:
        return xor(haxxor,f.read())