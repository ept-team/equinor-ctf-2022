#!/bin/bash
docker rm -f haxxor
docker build -t haxxor .
docker run --name=haxxor --rm -p5000:5000 -it haxxor
