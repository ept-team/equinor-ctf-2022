using MySqlConnector;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace handlerone;
class Handlertwo
{
    public static void Main()
    {
        var factory = new ConnectionFactory() { HostName = Environment.GetEnvironmentVariable("RABBITMQ_HOST") };
        var connection_open = false;
        IConnection test_connection = null;
        //As we do not know when the docker container is ready we need to maybe wait for it to be ready
        while (!connection_open)
        {
            try
            {
                test_connection = factory.CreateConnection();
                connection_open = true;
                Console.WriteLine("RabbitMQ ready - moving on");
            }
            catch (Exception ex)
            {
                Console.WriteLine("RabbitMQ not ready");
                System.Threading.Thread.Sleep(1000);
            }
        }
        //Now for some clean code
        using (var connection = factory.CreateConnection())
        {
            using (var channel = connection.CreateModel())
            {

                channel.QueueDeclare(queue: "tickets",
                                        durable: false,
                                        exclusive: false,
                                        autoDelete: false,
                                        arguments: null);
                var consumer = new EventingBasicConsumer(channel);
                channel.BasicConsume(queue: "tickets",
                                            autoAck: true,
                                            consumer: consumer);
        
                    consumer.Received += (model, ea) =>
                    {
                        try
                        {
                            var body = ea.Body.ToArray();
                            var message = Encoding.UTF8.GetString(body);
                            Ticket? ticket = JsonSerializer.Deserialize<Ticket>(message);

                            if (ticket != null)
                            {
                                var connection = new MySqlConnection(Environment.GetEnvironmentVariable("MYSQL_CONNECTIONSTRING"));
                                connection.Open();
                                var sql = "insert into tickets(title,note,user_id,status) values(@title,@note,@user_id,@status)";
                                var command = new MySqlCommand(sql, connection);
                                command.Parameters.AddWithValue("@title", ticket.Title);
                                command.Parameters.AddWithValue("@note", ticket.Note);
                                command.Parameters.AddWithValue("@user_id", ticket.UserId);
                                command.Parameters.AddWithValue("@status", "Work started");
                                var reader = command.ExecuteNonQuery();
                            }
                        }
                        catch (Exception ex)
                        {
                            //exception handling is for noobs
                        }
                    };
                    
                    Thread.Sleep(Timeout.Infinite);

            }
        }
    }
}
