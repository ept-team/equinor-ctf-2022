﻿using MySqlConnector;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

class Handlertwo
{
    public static void Main()
    {
        var factory = new ConnectionFactory() { HostName = Environment.GetEnvironmentVariable("RABBITMQ_HOST") };

        var connection_open = false;
        IConnection connection = null;
        while (!connection_open)
        {
            try
            {
                connection = factory.CreateConnection();
                connection_open = true;
                Console.WriteLine("RabbitMQ ready - moving on");
                System.Threading.Thread.Sleep(1000);
            }
            catch (Exception ex)
            {
                Console.WriteLine("RabbitMQ not ready");
                System.Threading.Thread.Sleep(1000);
            }
        }
        using (var channel = connection.CreateModel())
        {

            channel.QueueDeclare(queue: "comments",
                                 durable: false,
                                 exclusive: false,
                                 autoDelete: false,
                                 arguments: null);
            var consumer = new EventingBasicConsumer(channel);
    
                consumer.Received += (model, ea) =>
                {
                    try
                    {
                        var body = ea.Body.ToArray();
                        var message = Encoding.UTF8.GetString(body);
                        Comment? comment = JsonSerializer.Deserialize<Comment>(message);
                        if (comment != null)
                        {
                            var connection = new MySqlConnection(Environment.GetEnvironmentVariable("MYSQL_CONNECTIONSTRING"));
                            connection.Open();
                            var sql_find_parent_ticket = "select * from tickets where id=@ticket_id";

                            var cmd = new MySqlCommand(sql_find_parent_ticket, connection);
                            cmd.Parameters.AddWithValue("@ticket_id", comment.ticket_id);
                            var my_reader = cmd.ExecuteReader();
                            var ticket = new Ticket();
                            while (my_reader.Read())
                            {
                                ticket.Note = my_reader[1].ToString();
                                ticket.Title = my_reader[2].ToString();
                                ticket.UserId = Convert.ToInt32(my_reader[3]);
                            }
                            connection.Close();
                            connection.Open();

                            var sql = "insert into comments(note,user_id,ticket_id) values(@note,@user_id,@ticket_id)";
                            var command = new MySqlCommand(sql, connection);
                            command.Parameters.AddWithValue("@note", comment.note);
                            command.Parameters.AddWithValue("@user_id", ticket.UserId);
                            command.Parameters.AddWithValue("@ticket_id", comment.ticket_id);
                            var reader = command.ExecuteNonQuery();
                            if (ticket.UserId == 1)
                            {
                                SendMessage("admincomments", message);
                            }
                            connection.Close();
                            connection.Open();
                            try
                            {
                                var sql_update_ticket = "update tickets set status=@status where id=@ticket_id and and user_id =@userid";
                                var ticket_cmd = new MySqlCommand(sql_update_ticket, connection);
                                ticket_cmd.Parameters.AddWithValue("@status", "Working on it");
                                ticket_cmd.Parameters.AddWithValue("@ticket_id", comment.ticket_id);
                                ticket_cmd.Parameters.AddWithValue("@userid", comment.user_id);
                                ticket_cmd.ExecuteNonQuery();
                            }
                            catch (Exception ex)
                            {//No bigi if this do not work, I really do not care}
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        // If this goes wrong I blame iLoop for shitty code
                    }
                };
                channel.BasicConsume(queue: "comments",
                                     autoAck: true,
                                     consumer: consumer);
            
            Thread.Sleep(Timeout.Infinite);
        }

        
    }

    static void SendMessage(String queuename, String message)
    {
        var factory = new ConnectionFactory() { HostName = Environment.GetEnvironmentVariable("RABBITMQ_HOST") };
        using (var connection = factory.CreateConnection())
        using (var channel = connection.CreateModel())
        {
            channel.QueueDeclare(queue: queuename,
                                 durable: false,
                                 exclusive: false,
                                 autoDelete: false,
                                 arguments: null);


            var body = Encoding.UTF8.GetBytes(message);

            channel.BasicPublish(exchange: "",
                                 routingKey: queuename,
                                 basicProperties: null,
                                 body: body);
        }

    }
}
