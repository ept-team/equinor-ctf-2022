class Comment{
    public int user_id { get; set; }
    public int ticket_id { get; set; }
    public string note { get; set; }
}