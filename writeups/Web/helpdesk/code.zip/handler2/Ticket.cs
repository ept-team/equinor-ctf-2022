class Ticket{
    public string Title { get; set; }
    public string Note { get; set; }

    public int UserId { get; set; }

}