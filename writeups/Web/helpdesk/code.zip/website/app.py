from logging.config import listen
import os
import json
import time
from waitress import serve 
from email import message
from time import sleep
from flask import Flask, request, make_response, render_template, redirect, session
from flask_login import LoginManager, UserMixin, login_required, login_user, logout_user,current_user
from flask.helpers import url_for



from sqlalchemy import create_engine, inspect
from sqlalchemy.orm import sessionmaker

from models import User, Ticket, Comment
from forms import TicketForm, SearchForm, CommentForm, UserForm

from datetime import timedelta

from rabbit import Rabbit

app = Flask(__name__)
app.secret_key = 'Dummy_key'
app.permanent_session_lifetime = timedelta(days=5)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"
login_manager.session_protection = "basic"





not_ready = True
while(not_ready):
    try:
        engine = create_engine(os.environ['MYSQL_CONNECTIONSTRING'])
        sql_session_maker = sessionmaker(bind=engine)
        sql_session = sql_session_maker()
        admin_user = sql_session.query(User).filter_by(id=1).first()
        not_ready = False
        print("Database ready")
    except:
        print("Database not ready")
        time.sleep(5)
        pass

#Lets setup the chall
with open('flag.txt', 'r') as solution:
    try:
        sql_session = sql_session_maker()
        admin_user = sql_session.query(User).filter_by(id=1).first()
        sql_session.commit()
        if admin_user is None:
            user = User()
            user.password = "Dummy_password"
            user.username = "Admin"
            sql_session.add(user)
            sql_session.commit()
        ticket = sql_session.query(Ticket).filter_by(user_id=1,id=1).first()
        sql_session.commit()
        if ticket is None:
            flag = solution.readline()
            ticket = Ticket(title="Admin secret ticket", note=flag, user_id = 1)
            sql_session = sql_session_maker()
            sql_session.add(ticket)
            sql_session.commit()
    except:
        pass

@app.before_request
def func():
  session.modified = True

@login_manager.user_loader
def load_user(user_id):
    sql_session = sql_session_maker()
    user = sql_session.query(User).filter_by(id=user_id).first()
    return user

@login_manager.unauthorized_handler
def unauthorized():
    # do stuff
    return redirect(url_for('login'))

@app.route('/', methods=['GET', 'POST'])
def index():
    resp = redirect(url_for('tickets'))
    return resp


# Helper - Extract current page name from request 
def get_segment( request ):
    try:
        segment = request.path.split('/')[-1]
        if segment == '':
            segment = 'index'
        return segment    
    except:
        return None  


@app.route('/comment', methods=['POST', 'GET'])
@login_required
def comment():
    ticket_id = request.args.get('ticket_id')
    form = CommentForm(request.form)
    form.ticket_id.data = ticket_id
    if request.method == 'POST':
        if "EPT" not in form.note.data: 
            sql_session = sql_session_maker()
            t = sql_session.query(Ticket).filter_by(id=ticket_id).first()
            rmq = Rabbit()
            ticket = {"note":form.note.data,"ticket_id":int(t.id),"user_id":int(current_user.get_id())}
            message = json.dumps(ticket)
            rmq.send_message("comments",message)
            resp =  redirect(url_for('ticket',ticket_id=ticket_id))
            return resp
        else:
            resp =  make_response(render_template('noflag.html',message="Play nice, Please"))
            return resp
            
    else:
       
        segment = get_segment( request )
        resp =  make_response(render_template('comment.html', form=form,segment=segment))
        return resp

@app.route('/ticket/<int:ticket_id>', methods=['POST', 'GET'])
@app.route('/ticket', methods=['POST', 'GET'])
@login_required
def ticket(ticket_id=None):
    form = TicketForm(request.form)
    if request.method == 'POST':
        if "EPT" not in form.note.data:
            sql_session = sql_session_maker()
            rmq = Rabbit()
            ticket = {"Note":form.note.data,"Title":form.title.data,"UserId":int(current_user.get_id())}
            message = json.dumps(ticket)
            rmq.send_message("tickets",message)
            
            resp =  redirect(url_for('tickets'))
            return resp
        else:
            resp =  make_response(render_template('noflag.html',message="Play nice, Please"))
            return resp
            

    else:
        read_only = False
        if ticket_id:
            sql_session = sql_session_maker()
            ticket = sql_session.query(Ticket).filter_by(id=ticket_id, user_id = current_user.get_id()).first()
            if ticket:
                form.title.data = ticket.title
                form.note.data = ticket.note
                form.id.data = ticket.id
                form.status.data = ticket.status
                read_only = True
                comments = sql_session.query(Comment).filter_by(ticket_id=ticket_id, user_id = current_user.get_id()).all()
                segment = get_segment( request )
                resp =  make_response(render_template('ticket.html', form=form,segment=segment, read_only=read_only, comments=comments, ticket_id=ticket_id))
                return resp
            else:
                resp =  make_response(render_template('noaccess.html', message="No access"))
                return resp

        segment = get_segment( request )
        resp =  make_response(render_template('ticket.html', form=form,segment=segment, read_only=read_only, ticket_id=ticket_id))
        return resp



@app.route('/tickets', methods=['POST', 'GET'])
@login_required
def tickets():
    
    message = request.args.get('messages')
    if message == None:
        message = ''
    
    note = Ticket()
    note.title = 'Demo'
    note.note = 'This is my fancy note'
    sql_session = sql_session_maker()
    tickets = sql_session.query(Ticket).filter_by(user_id=current_user.get_id())
    
    segment = get_segment( request )
    resp = make_response(render_template('tickets.html', segment=segment, message=message, note=note, tickets=tickets))
    return resp

@app.route('/profile', methods=['GET'])
@login_required
def profile():
    form = UserForm()
    sql_session = sql_session_maker()
    user = sql_session.query(User).filter_by(id=current_user.get_id()).first()
    form.id.data = str(user.id)
    form.username.data = user.username
    segment = get_segment( request )
    resp = make_response(render_template('userprofile.html', segment=segment, form=form))
    return resp


@app.route('/search', methods=['POST', 'GET'])
def search():
    form = SearchForm(request.form)
    if request.method == 'POST':
        try:
            text = form.search.data
            sql_session = sql_session_maker()
            ticket = sql_session.query(Ticket).filter(note.contains(text),user_id = current_user.get_id()).first()
            resp = redirect(url_for('ticket',ticket_id = ticket.id))
            return resp
        except Exception as e:
            segment = get_segment( request )
            message = 'Something bad happend, please be nice to me!'
            resp = make_response(render_template('search.html',form=form,segment=segment,message=message))
            return resp

    segment = get_segment( request )
    resp = make_response(render_template('search.html',form=form,segment=segment))
    return resp


@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
       
        username = request.form['username']
        password = request.form['password']
        try:
            sql_session = sql_session_maker()
            user = sql_session.query(User).filter_by(username=username,password=password).first()
            sql_session.commit()
            if user != None:
                login_user(user)
                resp = redirect(url_for('tickets'))
                return resp
            else:
                msg = 'Unable to log you in'
                resp = redirect(url_for('login', msg=msg))
                return resp
        except Exception as e:
            pass
    else:
        resp = make_response(render_template('accounts/login.html'))
        return resp

@app.route('/logout', methods=[ 'GET'])
def logout():
    logout_user()
    resp = redirect(url_for('login'))
    return resp

@app.route('/register', methods=['POST', 'GET'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        try:
            user_object = User()
            user_object.username = username
            user_object.password = password
            sql_session = sql_session_maker()
            user = sql_session.query(User).filter_by(username=username).first()
            if user == None:
                sql_session.add(user_object)
                sql_session.commit()
            else:
                message = 'This user is already registered'
                resp = make_response(render_template('accounts/register.html',msg=message))
                return resp
           
           
        except Exception as e:
            sql_session.rollback()
            pass
        resp = redirect(url_for('login'))
        return resp
    else:
        resp = make_response(render_template('accounts/register.html'))
        return resp


if __name__ == "__main__":
    serve(app, listen='*:5000',threads=100)