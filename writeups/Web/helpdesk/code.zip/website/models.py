import os
import time
from sqlalchemy import Column, Integer, String, ForeignKey, Table
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import create_engine
from flask_login  import UserMixin

Base = declarative_base()

class User(Base, UserMixin):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String(255),unique=True)
    password = Column(String(255))
    

class Ticket(Base):
    __tablename__ = "tickets"
    id = Column(Integer, primary_key=True, autoincrement=True)
    note = Column(String(2048))
    title = Column(String(255))
    user_id = Column(Integer, ForeignKey("users.id"))
    status = Column(String(50))
    comments = relationship("Comment")

class Comment(Base):
    __tablename__ = "comments"
    id = Column(Integer, primary_key=True, autoincrement=True)
    note = Column(String(2048))
    user_id = Column(Integer, ForeignKey("users.id"))
    ticket_id = Column(Integer, ForeignKey("tickets.id"))

not_ready = True
engine = create_engine(os.environ['MYSQL_CONNECTIONSTRING'])
while(not_ready):
    try:
        Base.metadata.create_all(bind=engine)
        not_ready = False
        print("Database ready")
    except:
        print("Database not ready")
        time.sleep(5)
        pass