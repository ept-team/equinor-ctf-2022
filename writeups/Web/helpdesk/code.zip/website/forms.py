from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, Form, TextAreaField
from wtforms import validators
from wtforms.fields.simple import HiddenField
from wtforms.validators import DataRequired, InputRequired, Length

class LoginForm(FlaskForm):
    user_name  = StringField('UserName', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Sign In')

class TicketForm(FlaskForm):
    style={'style': 'font-size: 36px', 'readonly': False}
    title = StringField('Title', [validators.Length(min=1, max=- 1, message="You need to enter a title")], render_kw={"class":"form-control"})
    status = StringField('Status', [validators.Length(min=1, max=20, message="You need to enter a title")], render_kw={'readonly': True,"class":"form-control"})
    note  = TextAreaField('Description', [validators.Length(min=1, max=- 1, message="You need to enter a description")], render_kw={"class":"form-control"})
    id = HiddenField('id')
    submit = SubmitField('Save')

class CommentForm(FlaskForm):
    style={'style': 'font-size: 36px', 'readonly': False}
    note  = TextAreaField('Comment', [validators.Length(min=1, max=- 1, message="You need to enter a note")], render_kw={"class":"form-control"})
    id = HiddenField('id')
    ticket_id = HiddenField('ticket_id')
    user_id = HiddenField('user_id')
    submit = SubmitField('Save')

class SearchForm(FlaskForm):
    style={'style': 'font-size: 36px', 'readonly': False}
    search = StringField('Search', [validators.Length(min=1, max=- 1, message="You need to enter a title")], render_kw={"class":"form-control"})
    submit = SubmitField('Search')

class UserForm(FlaskForm):
    style={'style': 'font-size: 36px', 'readonly': True}
    id = StringField('User id', [validators.Length(min=1, max=- 1, message="You need to enter a title")], render_kw={'readonly': True,"class":"form-control"})
    username = StringField('User name', [validators.Length(min=1, max=- 1, message="You need to enter a title")], render_kw={'readonly': True,"class":"form-control"})
    