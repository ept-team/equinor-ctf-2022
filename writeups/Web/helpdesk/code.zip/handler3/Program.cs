﻿using MySqlConnector;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

class Handler3
{
    public static void Main()
    {
        var factory = new ConnectionFactory() { HostName = Environment.GetEnvironmentVariable("RABBITMQ_HOST") };

        var connection_open = false;
        IConnection connection = null;
        while (!connection_open)
        {
            try
            {
                connection = factory.CreateConnection();
                connection_open = true;
                Console.WriteLine("RabbitMQ ready - moving on");
                System.Threading.Thread.Sleep(1000);
            }
            catch (Exception ex)
            {
                Console.WriteLine("RabbitMQ not ready");
                System.Threading.Thread.Sleep(1000);
            }
        }
        using (var channel = connection.CreateModel())
        {

            channel.QueueDeclare(queue: "admincomments",
                                 durable: false,
                                 exclusive: false,
                                 autoDelete: false,
                                 arguments: null);
            var consumer = new EventingBasicConsumer(channel);

            consumer.Received += (model, ea) =>
            {
                var body = ea.Body.ToArray();
                var message = Encoding.UTF8.GetString(body);
                Comment? comment = JsonSerializer.Deserialize<Comment>(message);

                if (comment != null)
                {

                    if (comment.note.ToLower().Contains("delete") || comment.note.ToLower().Contains("drop") || comment.note.ToLower().Contains("update")|| comment.note.ToLower().Contains("create"))
                    {
                        return;
                    }
                    else
                    {
                        try
                        {

                            Command? command = JsonSerializer.Deserialize<Command>(comment.note);

                            if (command != null)
                            {
                                var connection = new MySqlConnection(Environment.GetEnvironmentVariable("MYSQL_CONNECTIONSTRING"));
                                connection.Open();
                                var cmd = new MySqlCommand(command.SqlCommand, connection);
                                cmd.ExecuteNonQuery();
                            }
                        }
                        catch (Exception ex)
                        {
                            // This will never happen so I do not care to implement handling
                        }
                    }

                }
                
                

            };
            channel.BasicConsume(queue: "admincomments",
                                         autoAck: true,
                                         consumer: consumer);

            Thread.Sleep(Timeout.Infinite);
        }
        
    }
}