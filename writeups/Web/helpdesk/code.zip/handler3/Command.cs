class Command{
    public string SqlCommand { get; set; }

}