def Rick():
    print("Hey? How did you do that? Are sure a pickle is a fruit?")
    print("You probably need this: EPT{dummy_flag}")
